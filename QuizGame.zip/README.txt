Quiz Game – Pythonowy Quiz Nauki 🧠

Jak uruchomić:
1. Upewnij się, że masz zainstalowanego Pythona (https://www.python.org/)
2. Otwórz terminal w folderze z plikami
3. Wpisz: python quiz.py

Wymagania:
- Python 3.7 lub nowszy
- Plik questions.json z pytaniami (znajduje się w folderze)

Dodatkowe informacje:
- Po zakończeniu quizu tworzony jest plik score.txt z Twoim wynikiem
- Pytania są losowane z różnych dziedzin nauki

Autor: Użytkownik ChatGPT